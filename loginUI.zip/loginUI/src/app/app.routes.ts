import { Routes } from '@angular/router';
import { LoginPageComponent } from './authentication/login-Page.component';
import { LogoutPageComponent } from './authentication/logout-page.component'



export const routConfig: Routes = [
    { path: '', pathMatch: 'full', redirectTo: 'login' },
    { path: 'login', component: LoginPageComponent },
    { path: 'logout', component: LogoutPageComponent }
]

