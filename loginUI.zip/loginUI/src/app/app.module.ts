import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { routConfig } from './app.routes'

import { LoginPageComponent } from './authentication/login-Page.component';
import { LogoutPageComponent } from './authentication/logout-page.component'


import { AppComponent } from './app.component';



@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routConfig),

    
  ],
  exports :[RouterModule],
  declarations: [
    AppComponent,
    LoginPageComponent,
    LogoutPageComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
