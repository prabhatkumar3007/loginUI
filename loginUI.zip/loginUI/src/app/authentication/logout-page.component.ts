import { Component, Input } from '@angular/core';


@Component({
  selector:'logout-Page',
  moduleId: 'module.id',
  templateUrl: 'logoutPage.html'
})
export class LogoutPageComponent {
  
}