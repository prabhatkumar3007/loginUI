import { Component, Input } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Router } from '@angular/router';

import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';


@Component({
  selector: 'login-page',
  moduleId: 'module.id',
  templateUrl: 'loginPage.html',
  styleUrls: ["loginPage.css"]
})
export class LoginPageComponent {
  constructor(public http: Http, private routes: Router) {

  }
  
  login(userName:string, password:string) {
    var creds="userName="+userName+"&password="+password;
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    this.http.post("http://localhost:8090/iot/app/users/authenticate", creds, { headers })
    .map(res => res.json())
    .subscribe(
      data => this.loginSucess(data),
      err => this.loginFail(err),
      () => console.log('Authentication Complete')
    );
  }
  loginSucess(data:any){
    console.log(data.data);
    
    if(data.data == "Success")
    {
      this.routes.navigate(['/logout']);
    }
    else{
      alert("error");
    }

  }
  loginFail(err:any){
    alert("error"+err);
  }
}