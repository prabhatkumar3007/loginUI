import { JbTestPage } from './app.po';

describe('jb-test App', function() {
  let page: JbTestPage;

  beforeEach(() => {
    page = new JbTestPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
