import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginComponent } from './login.component';
import { HomeComponent } from './home-page.component';
import { NavBarComponent } from './navbar.component';
import { NotFoundComponent } from './shared/not-found.component';

import { MessagesModule } from './messages/messages.module'; 
import { OtherModule } from './other/other.module';
import { PhotosModule } from './photos/photos.module';
import { SharedModule } from './shared/shared.module';
import { UsersModule } from './admin/users/users.module';
import { PostsModule } from './posts/posts.module';

import { usersRouting } from './admin/users/users.routing';
import { otherRouting } from './other/other.routing';
import { photosRouting } from './photos/photos.routing';
import { postsRouting } from './posts/posts.routing';
import { routing } from './app.routing';


import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth-guard.service';
import { PreventUnsavedChangesGuard } from './shared/prevent-unsaved-changes-guard.service';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    SharedModule,
    UsersModule,
    MessagesModule,
    OtherModule,
    PostsModule,
    PhotosModule,
    usersRouting,
    otherRouting,
    postsRouting,
    photosRouting,
    routing
  ],
  declarations: [ 
    AppComponent,
    LoginComponent,
    HomeComponent,
    NavBarComponent,
    NotFoundComponent
  ],
  providers: [ AuthService, AuthGuard, PreventUnsavedChangesGuard ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }