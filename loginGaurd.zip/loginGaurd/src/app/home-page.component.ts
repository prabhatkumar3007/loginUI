import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  template: `
  <navbar></navbar>
  <div class="container">
    <router-outlet></router-outlet>
  </div>
`
})
export class HomeComponent  {
}