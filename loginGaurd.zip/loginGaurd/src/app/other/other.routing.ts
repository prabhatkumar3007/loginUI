import { Router, RouterModule } from '@angular/router';

import { OtherComponent } from './other.component';

export const otherRouting = RouterModule.forChild([
  { path: 'other', component: OtherComponent }
]);