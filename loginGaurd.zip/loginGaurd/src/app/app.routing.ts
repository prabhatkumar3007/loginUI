import { Router, RouterModule } from '@angular/router';

import { LoginComponent } from './login.component';
import { HomeComponent } from './home-page.component';
import { MessagesComponent } from './messages/messages.component';
import { NotFoundComponent } from './shared/not-found.component';

import { AuthGuard } from './auth/auth-guard.service';
import { PreventUnsavedChangesGuard } from './shared/prevent-unsaved-changes-guard.service';

export const routing = RouterModule.forRoot([
  { path: '', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'not-found', component: NotFoundComponent },
  { path: 'messages', component: MessagesComponent, canActivate: [ AuthGuard ], canDeactivate: [ PreventUnsavedChangesGuard ] },
  { path: '**', redirectTo: 'not-found' }
]);