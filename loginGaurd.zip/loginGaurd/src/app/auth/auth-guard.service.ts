import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

import { AuthService } from './auth.service';
import { LoginComponent } from '../login.component';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor( private _router: Router,  private loginComponent: LoginComponent) {

  }

  canActivate() {
    console.log("..."+this.loginComponent.isLoggedIn)
    if (this.loginComponent.isLoggedIn)
      return true;

    this._router.navigate(['home']);

    return false;
  }
}