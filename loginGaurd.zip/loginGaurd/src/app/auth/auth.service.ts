import { Injectable } from '@angular/core'
import { Http, Headers } from '@angular/http';

import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';


@Injectable()
export class AuthService {
  constructor(public http: Http) { }
 // isLoggedIn = false;

  getLoginData(creds: string): Observable<any> {
   // this.isLoggedIn = true;
   // console.log(",.,"+this.isLoggedIn)
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    return this.http.post("http://localhost:8090/iot/app/users/authenticate", creds, { headers })
      .map(res => res.json());
  }
  getUserData(): Observable<any> {
    return this.http.get('http://localhost:8090/iot/app/users')
      .map(res => res.json());
  }

  logout() {
  //  this.isLoggedIn = false;
  }
}


