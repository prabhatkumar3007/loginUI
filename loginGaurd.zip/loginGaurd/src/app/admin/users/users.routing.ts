
import { RouterModule  }              from '@angular/router';

import { UserFormComponent }          from './user-form.component';
import { UsersComponent }             from './users.component';
import { PreventUnsavedChangesGuard } from '../../shared/prevent-unsaved-changes-guard.service';

export const usersRouting = RouterModule.forChild([
  {
    path: 'home/users/:id', 
    component: UserFormComponent,
    canDeactivate: [ PreventUnsavedChangesGuard ]
  },
  {
    path: 'home/users/new',
    component: UserFormComponent,
    canDeactivate: [ PreventUnsavedChangesGuard ]
  },
  { path: 'home/users', component: UsersComponent },
]);